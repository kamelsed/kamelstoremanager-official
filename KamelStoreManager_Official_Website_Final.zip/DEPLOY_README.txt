Kamel Store Manager - Deployment & Video Assembly Instructions

1) To publish site on GitHub Pages:
- Create repo 'kamelstoremanager-official' under user 'kamelsed'.
- Copy the contents of the 'site' folder into the repo root or into 'docs/' and enable Pages from settings.
- Commit and push. Site will be live at: https://kamelsed.github.io/kamelstoremanager-official/

2) To generate final MP4s with narration (example using ffmpeg and gTTS or any TTS):
- Create narration audio files from the text files located in 'site/assets/videos/narration_fr.txt' etc.
  Example using gTTS (requires internet):
    from gtts import gTTS
    t = gTTS(text=open('narration_fr.txt').read(), lang='fr')
    t.save('narration_fr.mp3')
- Combine intro + story images into a video and add audio with ffmpeg:
    ffmpeg -loop 1 -t 3 -i video_storyboard/intro.png -loop 1 -t 4 -i video_storyboard/story_1.png -loop 1 -t 4 -i video_storyboard/story_2.png -loop 1 -t 4 -i video_storyboard/story_3.png -loop 1 -t 4 -i video_storyboard/story_4.png -filter_complex "[0:v]format=yuv420p[v0];[1:v][2:v][3:v][4:v]concat=n=5:v=1:a=0[outv]" -map "[outv]" -c:v libx264 promo_temp.mp4
    ffmpeg -i promo_temp.mp4 -i assets/videos/narration_fr.mp3 -c:v copy -c:a aac -b:a 192k site/fr/promo_fr.mp4
- Repeat for en/ar using respective narration audio files.

3) PayPal integration:
- Replace sandbox PayPal client-id in the site with your live client-id from PayPal developer dashboard.
- For RedotPay, use the provider's checkout URL or API as instructed by their documentation.

